<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="shortcut icon" href="<?php echo e(URL::to('/')); ?>/favicon.ico">

    <title>GIHAL</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- bootstrap -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/bootstrap/bootstrap.css')); ?>">
    <script src="<?php echo e(url('/bootstrap/bootstrap.js')); ?>"></script>

    <!-- estilos estaticos -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/css/app.css')); ?>">
    <!-- campos de tipo calendario-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <!-- Scripts -->
    <script src="<?php echo e(url('/scripts/jquery-3.6.3/jquery-3.6.3.min.js')); ?>"></script>
    <script src="<?php echo e(url('/scripts/init.js')); ?>"></script>
    <!-- campos de tipo calendario-->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/es.js"></script>

    <!-- <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>-->
  
</head>

<body class="mb-4">
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container-fluid">

                <a class="navbar-brand d-flex align-items-center" href="<?php echo e(url('/')); ?>">
                    <img class="me-2" src="<?php echo e(URL::to('/')); ?>/images/logo.png" width="50" height="50" alt="">
                    <span class="h2 m-0">
                        GIHAL
                    </span>
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div id="navMenu" class="collapse navbar-collapse">
                    <?php if(Auth::check()): ?>

                    <ul class="navbar-nav me-auto">
                        <?php if(Auth::user()->es_administrador): ?>
                        <li class="nav-item dropdown">
                            <a id="navbarAdministracion" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                Administración
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarAdministracion">
                                <a class="dropdown-item" href="<?php echo e(route('usuario.index')); ?>"><?php echo e(__('Usuarios')); ?></a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::user()->es_gestor): ?>
                        <li class="nav-item dropdown">
                            <a id="navbarGestion" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                Gestiones
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarGestion">
                                <a class="dropdown-item" href="<?php echo e(route('ubicacion.index')); ?>"><?php echo e(__('Ubicaciones')); ?></a>
                                <a class="dropdown-item" href="<?php echo e(route('persona.index')); ?>"><?php echo e(__('Personas')); ?></a>
                                <a class="dropdown-item" href="<?php echo e(route('contratacion.index')); ?>"><?php echo e(__('Contrataciones')); ?></a>
                                <a class="dropdown-item" href="<?php echo e(route('tipo_equipo.index')); ?>"><?php echo e(__('Tipos de Equipo')); ?></a>
                                <a class="dropdown-item" href="<?php echo e(route('equipo.index')); ?>"><?php echo e(__('Equipos')); ?></a>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::user()->es_tecnico): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('operacion.index')); ?>"><?php echo e(__('Operaciones')); ?></a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::user()->es_consultor): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('consulta.index')); ?>"><?php echo e(__('Consultas')); ?></a>
                        </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(URL::to('/ayuda')); ?>"><?php echo e(__('Ayuda')); ?></a>
                        </li>
                    </ul>
                    <?php endif; ?>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                        <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>
                        <?php endif; ?>

                        <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                        </li>
                        <?php endif; ?>
                        <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->username); ?>

                            </a>

                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Cerrar sesión')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
<footer class="text-center text-lg-start fixed-bottom">

    <div class="text-center">
        © 2023 GIHAL. Gestión de Inventario Hardware para Admininistraciones Locales.
    </div>
</footer>

</html><?php /**PATH C:\xampp\htdocs\gihal\resources\views/layouts/app.blade.php ENDPATH**/ ?>