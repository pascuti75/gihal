





<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <h1 class="text-center">GESTIÓN DE CONTRATACIONES</h1>

    
    <?php if(Session::has('mensaje')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('mensaje')); ?>

    </div>
    <?php endif; ?>
    
    <?php if(Session::has('error') && Session::get('error')!==""): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(Session::get('error')); ?>

    </div>
    <?php endif; ?>


    
    <a href="<?php echo e(url('/contratacion/create')); ?>" class="btn btn-success">Crear contratación</a>
    <br><br>
    
    <form method="GET">
        <div class="input-group mb-3">
            <input type="search" name="query" id="query" value="<?php echo e(request()->get('query')); ?>" class="form-control" placeholder="Buscar..." aria-label="Buscar" aria-describedby="boton-buscar">
            <button class="btn btn-outline-success" type="submit" id="boton-buscar">Buscar</button>
            <button class="btn btn-outline-success" type="submit" id="boton-reset">Reset</button>
        </div>
    </form>

    <div class="card card-body">
        
        <table class="table table-light table-wide">
            <thead class="thead-light">
                <tr>
                    <th class="text-center">#</th>
                    <th class="text-left">Título</th>
                    <th class="text-left">Empresa</th>
                    <th class="text-center ancho-100">Fecha Inicio</th>
                    <th class="text-center ancho-100">Fecha Fin</th>
                    <th class="action-column text-nowrap text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $contrataciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contratacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($contratacion->id); ?></td>
                    <td><?php echo e($contratacion->titulo); ?></td>
                    <td><?php echo e($contratacion->empresa); ?></td>
                    <td class="text-center"><?php echo e(isset($contratacion->fecha_inicio) ? date('d/m/Y',strtotime($contratacion->fecha_inicio)):''); ?> </td>
                    <td class="text-center"><?php echo e(isset($contratacion->fecha_fin) ? date('d/m/Y',strtotime($contratacion->fecha_fin)):''); ?></td>
                    
                    <td class="text-center">
                        <a href="<?php echo e(url('/contratacion/'.$contratacion->id.'/edit')); ?>" class="btn btn-sm btn-warning">editar</a>
                        |
                        <form action="<?php echo e(url('/contratacion/'.$contratacion->id)); ?>" class="d-inline" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('DELETE')); ?>

                            <input type="submit" class="btn btn-sm btn-danger" onclick="return confirm('¿Quieres eliminar la contratación?')" value="eliminar">
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <?php echo $contrataciones->links(); ?>

        <?php echo e('Total registros: '. $contrataciones->total()); ?>

    </div>
</div>


<script>
    $(document).ready(function() {
        initContratacionIndex();
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gihal\resources\views/contratacion/index.blade.php ENDPATH**/ ?>