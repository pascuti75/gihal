<fieldset class="border border-dark border-1 p-4 mt-4">
    <legend class="float-none w-auto px-3 legend-form">
        FICHA DE OPERACIÓN
    </legend>

    
    <?php if(count($errors)>0): ?>
    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    
    <div class="row">
        <div class="col">
            <div class="form-group">
                <label for="tipo_operacion">Tipo de operación:</label>
                <input type="text" class="form-control" name="tipo_operacion" id="tipo_operacion" value="<?php echo e($tipo==='instalacion' ? 'instalacion' : $operacion->tipo_operacion); ?>" readonly>
            </div>
        </div>
        <div class="col">
            <div class="form-group">
                <?php if($tipo!=='instalacion'): ?>
                <label for="fecha_operacion">Fecha de operación:</label>
                <input type="text" class="form-control" name="fecha_operacion" id="fecha_operacion" value="<?php echo e($operacion->fecha_operacion); ?>" readonly>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col">
        <div class="form-group">
            <label for="id_equipo">Equipo:</label>
            <select class="form-select" name="id_equipo" id="id_equipo" disabled>
                <option value="option_select" disabled selected>Seleccionar</option>
                <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($equipo->id); ?>" <?php echo e(old('id') == $equipo->id ? 'selected' : ($operacion->id_equipo == $equipo->id ? 'selected' : '')); ?>><?php echo e($equipo->cod_interno . 
                    ' - ' . $equipo->marca . ' '. $equipo->modelo.' ('.$equipo->tipoEquipo->tipo.')'); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="col">
        <div class="form-group">
            <label for="id_persona">Persona:</label>
            <select class="form-select" name="id_persona" id="id_persona">
                <option value="">Seleccionar</option>
                <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($persona->id); ?>" <?php echo e(isset($operacion->id_persona ) ? (old('id_persona',$operacion->id_persona) == $persona->id ? 'selected' : '') : (old('id_persona') == $persona->id ? 'selected' : '')); ?>>
                    <?php echo e($persona->apellidos .', '. $persona->nombre); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="col">
        <div class="form-group">
            <label for="id_ubicacion">Ubicación:</label>
            <select class="form-select" name="id_ubicacion" id="id_ubicacion">
                <option value="option_select" disabled selected>Seleccionar</option>
                <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($ubicacion->id); ?>" <?php echo e(isset($operacion->id_ubicacion ) ? (old('id_ubicacion',$operacion->id_ubicacion) == $ubicacion->id ? 'selected' : '') : (old('id_ubicacion') == $ubicacion->id ? 'selected' : '')); ?>><?php echo e($ubicacion->servicio .' - '. 
                    $ubicacion->dependencia .' - '. $ubicacion->direccion .' - ' . ' Planta ' . $ubicacion->planta); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="col">
        <div class="form-group">
            <label for="id_user">Técnico:</label>
            <select class="form-select" name="id_user" id="id_user" disabled>
                <option value="option_select" disabled selected>Seleccionar</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>" <?php echo e(old('id') == $user->id ? 'selected' : (auth()->user()->id == $user->id ? 'selected' : '')); ?>><?php echo e($user->username); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

</fieldset>

<br>

<input type="submit" class="btn btn-success" value="Aceptar">
<a href="<?php echo e(url('/operacion')); ?>" class="btn btn-primary">Cancelar</a>


<script>
    $(document).ready(function() {
        initOperacionForm();
    });
</script><?php /**PATH C:\xampp\htdocs\gihal\resources\views/operacion/form.blade.php ENDPATH**/ ?>