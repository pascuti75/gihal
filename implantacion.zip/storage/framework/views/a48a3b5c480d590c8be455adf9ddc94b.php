<fieldset class="border border-dark border-1 p-4 mt-4">
    <legend class="float-none w-auto px-3 legend-form">
        FICHA DE PERSONA
    </legend>

    
    <?php if(count($errors)>0): ?>
    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    
    <div class="form-group">
        <label for="nombre">Nombre:</label>
        <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo e(old('nombre', isset($persona->nombre)?$persona->nombre:old('nombre'))); ?>">
    </div>

    <div class="form-group">
        <label for="apellidos">Apellidos:</label>
        <input type="text" class="form-control" name="apellidos" id="apellidos" value="<?php echo e(old('apellidos', isset($persona->apellidos)?$persona->apellidos:old('apellidos'))); ?>">
    </div>


    <div class="col">
        <div class="form-group">
            <label for="tipo_personal">Tipo:</label>
            <select class="form-select" name="tipo_personal" id="tipo_personal">
                <option value="interno" <?php echo e(isset($persona->tipo_personal) ? (old('tipo_personal',$persona->tipo_personal) == "interno" ? 'selected' : '') : (old('tipo_personal') =="interno" ? 'selected' : '')); ?>>interno</option>
                <option value="externo" <?php echo e(isset($persona->tipo_personal) ? (old('tipo_personal',$persona->tipo_personal) == "externo" ? 'selected' : '') : (old('tipo_personal') =="externo" ? 'selected' : '')); ?>>externo</option>
            </select>
        </div>
    </div>

</fieldset>

<br>

<input type="submit" class="btn btn-success" value="Aceptar">
<a href="<?php echo e(url('/persona')); ?>" class="btn btn-primary">Cancelar</a><?php /**PATH C:\xampp\htdocs\gihal\resources\views/persona/form.blade.php ENDPATH**/ ?>