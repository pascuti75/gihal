<fieldset class="border border-dark border-1 p-4 mt-4">
    <legend class="float-none w-auto px-3 legend-form">
        FICHA DE UBICACIÓN
    </legend>

    
    <?php if(count($errors)>0): ?>
    <div class="alert alert-danger" role="alert">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    
    <div class="form-group">
        <label for="servicio">Servicio:</label>
        <input type="text" class="form-control" name="servicio" id="servicio" value="<?php echo e(old('servicio', isset($ubicacion->servicio)?$ubicacion->servicio:old('servicio'))); ?>">
    </div>

    <div class="form-group">
        <label for="dependencia">Dependencia:</label>
        <input type="text" class="form-control" name="dependencia" id="dependencia" value="<?php echo e(old('dependencia', isset($ubicacion->dependencia)?$ubicacion->dependencia:old('dependencia'))); ?>">
    </div>

    <div class="form-group">
        <label for="direccion">Dirección:</label>
        <input type="text" class="form-control" name="direccion" id="direccion" value="<?php echo e(old('direccion', isset($ubicacion->direccion)?$ubicacion->direccion:old('direccion'))); ?>">
    </div>

    <div class="form-group">
        <label for="planta">Planta:</label>
        <input type="text" class="form-control" name="planta" id="planta" value="<?php echo e(old('planta', isset($ubicacion->planta)?$ubicacion->planta:old('planta'))); ?>">
    </div>


</fieldset>

<br>

<input type="submit" class="btn btn-success" value="Aceptar">
<a href="<?php echo e(url('/ubicacion')); ?>" class="btn btn-primary">Cancelar</a><?php /**PATH C:\xampp\htdocs\gihal\resources\views/ubicacion/form.blade.php ENDPATH**/ ?>