





<?php $__env->startSection('content'); ?>
<div class="container">

    <h1 class="text-center">GESTIÓN DE EQUIPOS</h1>

    
    <?php if(Session::has('mensaje')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('mensaje')); ?>

    </div>
    <?php endif; ?>
    
    <?php if(Session::has('error') && Session::get('error')!==""): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(Session::get('error')); ?>

    </div>
    <?php endif; ?>


    
    <a href="<?php echo e(url('/equipo/create')); ?>" class="btn btn-success">Crear equipo</a>
    <br><br>
    
    <form method="GET">
        <div class="input-group mb-3">
            <input type="search" name="query" id="query" value="<?php echo e(request()->get('query')); ?>" class="form-control" placeholder="Buscar..." aria-label="Buscar" aria-describedby="boton-buscar">
            <button class="btn btn-outline-success" type="submit" id="boton-buscar">Buscar</button>
            <button class="btn btn-outline-success" type="submit" id="boton-reset">Reset</button>
        </div>
    </form>

    <div class="card card-body">
        
        <table class="table table-light">
            <thead class="thead-light">
                <tr>
                    <th>#</th>
                    <th>Marca</th>
                    <th>Modelo</th>
                    <th>Cod.Interno</th>
                    <th>Cod.Externo</th>
                    <th>Num.Serie</th>
                    <th>Product Number</th>
                    <th class="text-center">Contrato</th>
                    <th class="text-center">Tipo Equipo</th>
                    <th class="action-column text-nowrap text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($equipo->id); ?></td>
                    <td><?php echo e($equipo->marca); ?></td>
                    <td><?php echo e($equipo->modelo); ?></td>
                    <td><?php echo e($equipo->cod_interno); ?></td>
                    <td><?php echo e($equipo->cod_externo); ?></td>
                    <td><?php echo e($equipo->num_serie); ?></td>
                    <td><?php echo e($equipo->product_number); ?></td>
                    
                    <td class="text-center">
                        <?php if($equipo->id_contratacion!=null): ?>
                        <a class="btn btn-sm btn-outline-secondary" href="#" data-toggle="tooltip" title="<?php echo e($equipo->contratacion->empresa.': '.$equipo->contratacion->titulo . 
                        '   Fecha Inicio: '. date('d/m/Y',strtotime($equipo->contratacion->fecha_inicio)) . '   Fecha Fin: '. 
                        date('d/m/Y',strtotime($equipo->contratacion->fecha_fin))); ?>">ver</a>
                        <?php endif; ?>
                    </td>
                    <td class="text-center"><?php echo e($equipo->tipoEquipo->tipo); ?></td>
                    <td class="action-column text-nowrap text-center">
                        <a href="<?php echo e(url('/equipo/'.$equipo->id.'/edit')); ?>" class="btn btn-sm btn-warning">editar</a>
                        |
                        <form action="<?php echo e(url('/equipo/'.$equipo->id)); ?>" class="d-inline" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('DELETE')); ?>

                            <input type="submit" class="btn btn-sm btn-danger" onclick="return confirm('¿Quieres eliminar el equipo?')" value="eliminar">
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <?php echo $equipos->links(); ?>

        <?php echo e('Total registros: '. $equipos->total()); ?>

    </div>
</div>


<script>
    $(document).ready(function() {
        initEquipoIndex();
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gihal\resources\views/equipo/index.blade.php ENDPATH**/ ?>