





<?php $__env->startSection('content'); ?>
<div class="container">

    <h1 class="text-center">GESTIÓN DE TIPOS DE EQUIPO</h1>

    
    <?php if(Session::has('mensaje')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('mensaje')); ?>

    </div>
    <?php endif; ?>
    
    <?php if(Session::has('error') && Session::get('error')!==""): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(Session::get('error')); ?>

    </div>
    <?php endif; ?>

    
    <a href="<?php echo e(url('/tipo_equipo/create')); ?>" class="btn btn-success">Crear tipo</a>
    <br><br>
    
    <form method="GET">
        <div class="input-group mb-3">
            <input type="search" name="query" id="query" value="<?php echo e(request()->get('query')); ?>" class="form-control" placeholder="Buscar..." aria-label="Buscar" aria-describedby="boton-buscar">
            <button class="btn btn-outline-success" type="submit" id="boton-buscar">Buscar</button>
            <button class="btn btn-outline-success" type="submit" id="boton-reset">Reset</button>
        </div>
    </form>

    <div class="card card-body">
        
        <table class="table table-light">
            <thead class="thead-light">
                <tr>
                    <th class="ancho-50">Código</th>
                    <th>Tipo</th>
                    <th class="action-column text-nowrap text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $tipos_equipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="ancho-50"><?php echo e($tipo_equipo->cod_tipo_equipo); ?></td>
                    <td><?php echo e($tipo_equipo->tipo); ?></td>
                    
                    <td class="action-column text-nowrap text-center">
                        <a href="<?php echo e(url('/tipo_equipo/'.$tipo_equipo->id.'/edit')); ?>" class="btn btn-sm btn-warning">editar</a>
                        |
                        <form action="<?php echo e(url('/tipo_equipo/'.$tipo_equipo->id)); ?>" class="d-inline" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('DELETE')); ?>

                            <input type="submit" class="btn btn-sm btn-danger" onclick="return confirm('¿Quieres eliminar el tipo de equipo?')" value="eliminar">
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <?php echo $tipos_equipo->links(); ?>

        <?php echo e('Total registros: '. $tipos_equipo->total()); ?>

    </div>
</div>


<script>
    $(document).ready(function() {
        initTipoEquipoIndex();
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gihal\resources\views/tipo_equipo/index.blade.php ENDPATH**/ ?>