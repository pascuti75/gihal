





<?php $__env->startSection('content'); ?>
<div class="container">

    <h1 class="text-center">GESTIÓN DE UBICACIONES</h1>

    
    <?php if(Session::has('mensaje')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(Session::get('mensaje')); ?>

    </div>
    <?php endif; ?>
    
    <?php if(Session::has('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(Session::get('error')); ?>

    </div>
    <?php endif; ?>

    
    <a href="<?php echo e(url('/ubicacion/create')); ?>" class="btn btn-success">Crear ubicación</a>
    <br><br>
    
    <form method="GET">
        <div class="input-group mb-3">
            <input type="search" name="query" id="query" value="<?php echo e(request()->get('query')); ?>" class="form-control" placeholder="Buscar..." aria-label="Buscar" aria-describedby="boton-buscar">
            <button class="btn btn-outline-success" type="submit" id="boton-buscar">Buscar</button>
            <button class="btn btn-outline-success" type="submit" id="boton-reset">Reset</button>
        </div>
    </form>

    <div class="card card-body">
        
        <table class="table table-light">
            <thead class="thead-light">
                <tr>
                    <th>#</th>
                    <th>Servicio</th>
                    <th>Dependencia</th>
                    <th>Dirección</th>
                    <th class="text-center">Planta</th>
                    <th class="action-column text-nowrap text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
                
                <?php $__currentLoopData = $ubicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ubicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($ubicacion->id); ?></td>
                    <td><?php echo e($ubicacion->servicio); ?></td>
                    <td><?php echo e($ubicacion->dependencia); ?></td>
                    <td><?php echo e($ubicacion->direccion); ?></td>
                    
                    <td class="text-center"><?php echo e($ubicacion->planta); ?></td>
                    <td class="action-column text-nowrap text-center">
                        <a href="<?php echo e(url('/ubicacion/'.$ubicacion->id.'/edit')); ?>" class="btn btn-sm btn-warning">editar</a>
                        |
                        <form action="<?php echo e(url('/ubicacion/'.$ubicacion->id)); ?>" class="d-inline" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('DELETE')); ?>

                            <input type="submit" class="btn btn-sm btn-danger" onclick="return confirm('¿Quieres eliminar la ubicación?')" value="eliminar">
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <?php echo $ubicaciones->links(); ?>

        <?php echo e('Total registros: '. $ubicaciones->total()); ?>

    </div>
</div>


<script>
    $(document).ready(function() {
        initUbicacionIndex();
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gihal\resources\views/ubicacion/index.blade.php ENDPATH**/ ?>